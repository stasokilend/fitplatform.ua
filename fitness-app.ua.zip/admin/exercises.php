<?php
require_once __DIR__ . '/../includes/config.php';
session_start();
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('admin');

$db = new Database();
$currentUser = getCurrentUser();

$error = '';
$success = '';

// Обробка дій
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $duration = intval($_POST['duration'] ?? 10);
        $caloriesPerMin = floatval($_POST['calories_per_min'] ?? 5.0);
        $metValue = floatval($_POST['met_value'] ?? 3.0);
        $difficulty = intval($_POST['difficulty'] ?? 1);
        $muscleGroups = $_POST['muscle_groups'] ?? [];
        $restrictions = $_POST['restrictions'] ?? [];

        if (empty($name)) {
            $error = 'Вкажіть назву вправи';
        } else {
            $result = $db->execute(
                "INSERT INTO exercises (name, description, duration, calories_per_min, met_value, difficulty, muscle_groups, restrictions)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                [
                    $name,
                    $description,
                    $duration,
                    $caloriesPerMin,
                    $metValue,
                    $difficulty,
                    json_encode($muscleGroups),
                    json_encode(array_map('intval', $restrictions))
                ]
            );

            if ($result) {
                $success = 'Вправу успішно додано!';
            } else {
                $error = 'Помилка додавання вправи';
            }
        }
    } elseif ($action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $duration = intval($_POST['duration'] ?? 10);
        $caloriesPerMin = floatval($_POST['calories_per_min'] ?? 5.0);
        $metValue = floatval($_POST['met_value'] ?? 3.0);
        $difficulty = intval($_POST['difficulty'] ?? 1);
        $muscleGroups = $_POST['muscle_groups'] ?? [];
        $restrictions = $_POST['restrictions'] ?? [];

        if (empty($name)) {
            $error = 'Вкажіть назву вправи';
        } else {
            $result = $db->execute(
                "UPDATE exercises SET name = ?, description = ?, duration = ?, calories_per_min = ?,
                 met_value = ?, difficulty = ?, muscle_groups = ?, restrictions = ?
                 WHERE id = ?",
                [
                    $name,
                    $description,
                    $duration,
                    $caloriesPerMin,
                    $metValue,
                    $difficulty,
                    json_encode($muscleGroups),
                    json_encode(array_map('intval', $restrictions)),
                    $id
                ]
            );

            if ($result !== false) {
                $success = 'Вправу успішно оновлено!';
            } else {
                $error = 'Помилка оновлення вправи';
            }
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $result = $db->execute("DELETE FROM exercises WHERE id = ?", [$id]);

        if ($result !== false) {
            $success = 'Вправу успішно видалено!';
        } else {
            $error = 'Помилка видалення вправи';
        }
    }
}

// Отримати всі вправи
$exercises = $db->query("SELECT * FROM exercises ORDER BY name");

// Отримати всі обмеження для форми
$allRestrictions = $db->query("SELECT * FROM medical_restrictions ORDER BY name");

// Якщо редагування - отримати дані вправи
$editExercise = null;
if (isset($_GET['edit'])) {
    $editId = intval($_GET['edit']);
    $editExercise = $db->fetchOne("SELECT * FROM exercises WHERE id = ?", [$editId]);
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Управління вправами - Адмін панель</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Управління вправами</h2>
            <a href="/admin/" class="btn btn-outline-secondary">Назад</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= e($success) ?></div>
        <?php endif; ?>

        <div class="row">
            <!-- Форма -->
            <div class="col-lg-4">
                <div class="card shadow sticky-top" style="top: 20px;">
                    <div class="card-body">
                        <h5 class="card-title mb-4">
                            <?= $editExercise ? 'Редагувати вправу' : 'Додати нову вправу' ?>
                        </h5>

                        <form method="POST" action="">
                            <input type="hidden" name="action" value="<?= $editExercise ? 'edit' : 'add' ?>">
                            <?php if ($editExercise): ?>
                                <input type="hidden" name="id" value="<?= $editExercise['id'] ?>">
                            <?php endif; ?>

                            <div class="mb-3">
                                <label class="form-label">Назва <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="name"
                                       value="<?= e($editExercise['name'] ?? '') ?>" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Опис</label>
                                <textarea class="form-control" name="description" rows="3"><?= e($editExercise['description'] ?? '') ?></textarea>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Тривалість (хв)</label>
                                    <input type="number" class="form-control" name="duration"
                                           value="<?= e($editExercise['duration'] ?? 10) ?>" min="1" max="60" required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Складність</label>
                                    <select class="form-select" name="difficulty" required>
                                        <option value="1" <?= ($editExercise['difficulty'] ?? 1) == 1 ? 'selected' : '' ?>>Легка</option>
                                        <option value="2" <?= ($editExercise['difficulty'] ?? 1) == 2 ? 'selected' : '' ?>>Середня</option>
                                        <option value="3" <?= ($editExercise['difficulty'] ?? 1) == 3 ? 'selected' : '' ?>>Складна</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Ккал/хв</label>
                                    <input type="number" class="form-control" name="calories_per_min"
                                           value="<?= e($editExercise['calories_per_min'] ?? 5.0) ?>"
                                           min="1" max="50" step="0.1" required>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label class="form-label">MET</label>
                                    <input type="number" class="form-control" name="met_value"
                                           value="<?= e($editExercise['met_value'] ?? 3.0) ?>"
                                           min="1" max="20" step="0.1" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">М'язові групи</label>
                                <?php
                                $editMuscleGroups = $editExercise ? json_decode($editExercise['muscle_groups'], true) ?? [] : [];
                                $muscleGroupsList = ['chest', 'back', 'shoulders', 'arms', 'triceps', 'biceps', 'core', 'abs', 'obliques', 'legs', 'quadriceps', 'hamstrings', 'glutes', 'calves', 'cardio', 'full_body'];
                                ?>
                                <div class="muscle-groups-container" style="max-height: 150px; overflow-y: auto;">
                                    <?php foreach ($muscleGroupsList as $group): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="muscle_groups[]"
                                                   value="<?= $group ?>" id="mg_<?= $group ?>"
                                                   <?= in_array($group, $editMuscleGroups) ? 'checked' : '' ?>>
                                            <label class="form-check-label small" for="mg_<?= $group ?>">
                                                <?= $group ?>
                                            </label>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Заборонено при обмеженнях</label>
                                <?php
                                $editRestrictions = $editExercise ? json_decode($editExercise['restrictions'], true) ?? [] : [];
                                ?>
                                <?php foreach ($allRestrictions as $restriction): ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="restrictions[]"
                                               value="<?= $restriction['id'] ?>" id="r_<?= $restriction['id'] ?>"
                                               <?= in_array($restriction['id'], $editRestrictions) ? 'checked' : '' ?>>
                                        <label class="form-check-label" for="r_<?= $restriction['id'] ?>">
                                            <?= e($restriction['name']) ?>
                                        </label>
                                    </div>
                                <?php endforeach; ?>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <?= $editExercise ? 'Оновити' : 'Додати' ?>
                                </button>
                                <?php if ($editExercise): ?>
                                    <a href="/admin/exercises.php" class="btn btn-outline-secondary">Скасувати</a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Список вправ -->
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Список вправ (<?= count($exercises) ?>)</h5>

                        <div class="table-responsive">
                            <table class="table table-hover admin-table">
                                <thead>
                                    <tr>
                                        <th>Назва</th>
                                        <th>Складність</th>
                                        <th>Тривалість</th>
                                        <th>Ккал/хв</th>
                                        <th>Дії</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($exercises as $exercise): ?>
                                        <tr>
                                            <td>
                                                <strong><?= e($exercise['name']) ?></strong>
                                                <?php if ($exercise['description']): ?>
                                                    <br><small class="text-muted"><?= e(substr($exercise['description'], 0, 50)) ?>...</small>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php
                                                $difficultyLabels = [1 => 'Легка', 2 => 'Середня', 3 => 'Складна'];
                                                $difficultyColors = [1 => 'success', 2 => 'warning', 3 => 'danger'];
                                                ?>
                                                <span class="badge bg-<?= $difficultyColors[$exercise['difficulty']] ?>">
                                                    <?= $difficultyLabels[$exercise['difficulty']] ?>
                                                </span>
                                            </td>
                                            <td><?= $exercise['duration'] ?> хв</td>
                                            <td><?= $exercise['calories_per_min'] ?></td>
                                            <td class="admin-actions">
                                                <a href="?edit=<?= $exercise['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                    Редагувати
                                                </a>
                                                <form method="POST" action="" class="d-inline"
                                                      onsubmit="return confirm('Видалити вправу?')">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?= $exercise['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                                        Видалити
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>
