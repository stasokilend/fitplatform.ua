<?php
require_once __DIR__ . '/../includes/config.php';
session_start();
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('admin');

$db = new Database();
$currentUser = getCurrentUser();

// Статистика
$totalUsers = $db->fetchOne("SELECT COUNT(*) as count FROM users")['count'];
$totalExercises = $db->fetchOne("SELECT COUNT(*) as count FROM exercises")['count'];
$totalWorkouts = $db->fetchOne("SELECT COUNT(*) as count FROM workout_sessions WHERE completed_at IS NOT NULL")['count'];
$totalRestrictions = $db->fetchOne("SELECT COUNT(*) as count FROM medical_restrictions")['count'];
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Адміністративна панель - Фітнес Платформа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Адміністративна панель</h2>
            <a href="/dashboard.php" class="btn btn-outline-secondary">Назад до головної</a>
        </div>

        <!-- Статистика -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="card stat-card bg-primary text-white">
                    <div class="card-body text-center">
                        <h6 class="opacity-75">Користувачів</h6>
                        <h2><?= $totalUsers ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-success text-white">
                    <div class="card-body text-center">
                        <h6 class="opacity-75">Вправ</h6>
                        <h2><?= $totalExercises ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-info text-white">
                    <div class="card-body text-center">
                        <h6 class="opacity-75">Тренувань</h6>
                        <h2><?= $totalWorkouts ?></h2>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-warning text-white">
                    <div class="card-body text-center">
                        <h6 class="opacity-75">Обмежень</h6>
                        <h2><?= $totalRestrictions ?></h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- Меню -->
        <div class="row g-4">
            <div class="col-md-6">
                <div class="card shadow h-100">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Управління вправами</h5>
                        <p class="card-text text-muted">Додавання, редагування та видалення вправ з бази даних</p>
                        <a href="/admin/exercises.php" class="btn btn-primary">Перейти до вправ</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow h-100">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Медичні обмеження</h5>
                        <p class="card-text text-muted">Управління довідником медичних обмежень</p>
                        <a href="/admin/restrictions.php" class="btn btn-primary">Перейти до обмежень</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow h-100">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Користувачі</h5>
                        <p class="card-text text-muted">Перегляд списку користувачів та їх профілів</p>
                        <a href="/admin/users.php" class="btn btn-primary">Переглянути користувачів</a>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card shadow h-100">
                    <div class="card-body">
                        <h5 class="card-title mb-3">Загальна статистика</h5>
                        <p class="card-text text-muted">Аналітика та звіти по платформі</p>
                        <a href="/admin/statistics.php" class="btn btn-primary">Переглянути статистику</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Останні користувачі -->
        <div class="card shadow mt-4">
            <div class="card-body">
                <h5 class="card-title mb-4">Останні зареєстровані користувачі</h5>
                <?php
                $recentUsers = $db->query(
                    "SELECT u.*, up.age, up.fitness_level
                     FROM users u
                     LEFT JOIN user_profiles up ON up.user_id = u.id
                     ORDER BY u.created_at DESC
                     LIMIT 5"
                );
                ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Email</th>
                                <th>Роль</th>
                                <th>Профіль</th>
                                <th>Дата реєстрації</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentUsers as $user): ?>
                                <tr>
                                    <td><?= e($user['email']) ?></td>
                                    <td>
                                        <span class="badge bg-<?= $user['role'] === 'admin' ? 'danger' : 'primary' ?>">
                                            <?= e($user['role']) ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($user['age']): ?>
                                            <span class="badge bg-success">Заповнено</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Не заповнено</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= formatDate($user['created_at']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>
