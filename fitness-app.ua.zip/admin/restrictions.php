<?php
require_once __DIR__ . '/../includes/config.php';
session_start();
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireRole('admin');

$db = new Database();
$currentUser = getCurrentUser();

$error = '';
$success = '';

// Обробка дій
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');

        if (empty($name)) {
            $error = 'Вкажіть назву обмеження';
        } else {
            $result = $db->execute(
                "INSERT INTO medical_restrictions (name, description) VALUES (?, ?)",
                [$name, $description]
            );

            if ($result) {
                $success = 'Обмеження успішно додано!';
            } else {
                $error = 'Помилка додавання обмеження';
            }
        }
    } elseif ($action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');

        if (empty($name)) {
            $error = 'Вкажіть назву обмеження';
        } else {
            $result = $db->execute(
                "UPDATE medical_restrictions SET name = ?, description = ? WHERE id = ?",
                [$name, $description, $id]
            );

            if ($result !== false) {
                $success = 'Обмеження успішно оновлено!';
            } else {
                $error = 'Помилка оновлення обмеження';
            }
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);

        // Перевірити чи обмеження використовується
        $usersCount = $db->fetchOne(
            "SELECT COUNT(*) as count FROM user_restrictions WHERE restriction_id = ?",
            [$id]
        )['count'];

        if ($usersCount > 0) {
            $error = "Обмеження використовується $usersCount користувачами. Видалення неможливе.";
        } else {
            $result = $db->execute("DELETE FROM medical_restrictions WHERE id = ?", [$id]);

            if ($result !== false) {
                $success = 'Обмеження успішно видалено!';
            } else {
                $error = 'Помилка видалення обмеження';
            }
        }
    }
}

// Отримати всі обмеження з кількістю користувачів
$restrictions = $db->query(
    "SELECT mr.*,
            (SELECT COUNT(*) FROM user_restrictions WHERE restriction_id = mr.id) as users_count
     FROM medical_restrictions mr
     ORDER BY mr.name"
);

// Якщо редагування - отримати дані
$editRestriction = null;
if (isset($_GET['edit'])) {
    $editId = intval($_GET['edit']);
    $editRestriction = $db->fetchOne("SELECT * FROM medical_restrictions WHERE id = ?", [$editId]);
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Медичні обмеження - Адмін панель</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Медичні обмеження</h2>
            <a href="/admin/" class="btn btn-outline-secondary">Назад</a>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= e($success) ?></div>
        <?php endif; ?>

        <div class="row">
            <!-- Форма -->
            <div class="col-lg-4">
                <div class="card shadow sticky-top" style="top: 20px;">
                    <div class="card-body">
                        <h5 class="card-title mb-4">
                            <?= $editRestriction ? 'Редагувати обмеження' : 'Додати нове обмеження' ?>
                        </h5>

                        <form method="POST" action="">
                            <input type="hidden" name="action" value="<?= $editRestriction ? 'edit' : 'add' ?>">
                            <?php if ($editRestriction): ?>
                                <input type="hidden" name="id" value="<?= $editRestriction['id'] ?>">
                            <?php endif; ?>

                            <div class="mb-3">
                                <label class="form-label">Назва <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="name"
                                       value="<?= e($editRestriction['name'] ?? '') ?>"
                                       placeholder="Наприклад: Грижа хребта" required>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Опис</label>
                                <textarea class="form-control" name="description" rows="4"
                                          placeholder="Детальний опис обмеження та рекомендації"><?= e($editRestriction['description'] ?? '') ?></textarea>
                            </div>

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <?= $editRestriction ? 'Оновити' : 'Додати' ?>
                                </button>
                                <?php if ($editRestriction): ?>
                                    <a href="/admin/restrictions.php" class="btn btn-outline-secondary">Скасувати</a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Список обмежень -->
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Список обмежень (<?= count($restrictions) ?>)</h5>

                        <?php if (empty($restrictions)): ?>
                            <p class="text-muted text-center py-4">Обмежень ще не додано</p>
                        <?php else: ?>
                            <div class="list-group">
                                <?php foreach ($restrictions as $restriction): ?>
                                    <div class="list-group-item">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <div class="flex-grow-1">
                                                <h6 class="mb-1"><?= e($restriction['name']) ?></h6>
                                                <?php if ($restriction['description']): ?>
                                                    <p class="mb-2 text-muted small"><?= e($restriction['description']) ?></p>
                                                <?php endif; ?>
                                                <small class="text-muted">
                                                    Користувачів: <span class="badge bg-info"><?= $restriction['users_count'] ?></span>
                                                </small>
                                            </div>
                                            <div class="admin-actions ms-3">
                                                <a href="?edit=<?= $restriction['id'] ?>" class="btn btn-sm btn-outline-primary mb-1">
                                                    Редагувати
                                                </a>
                                                <form method="POST" action="" class="d-inline"
                                                      onsubmit="return confirm('Видалити обмеження?<?= $restriction['users_count'] > 0 ? ' Увага: обмеження використовується користувачами!' : '' ?>')">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?= $restriction['id'] ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger"
                                                            <?= $restriction['users_count'] > 0 ? 'disabled title="Використовується користувачами"' : '' ?>>
                                                        Видалити
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>
