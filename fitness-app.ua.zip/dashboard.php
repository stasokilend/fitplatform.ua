<?php
require_once __DIR__ . '/includes/config.php';
session_start();
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireAuth();

$userId = getCurrentUserId();
$db = new Database();

// Перевірити чи є профіль
if (!hasProfile($userId)) {
    header('Location: /profile.php');
    exit;
}

// Отримати дані користувача та профіль
$profile = $db->fetchOne(
    "SELECT up.*, u.email, u.role
     FROM user_profiles up
     JOIN users u ON u.id = up.user_id
     WHERE up.user_id = ?",
    [$userId]
);

// Отримати статистику
$stats = getUserStats($userId, 30);

// Розрахувати ІМТ
$bmi = calculateBMI($profile['weight'], $profile['height']);
$bmiCategory = getBMICategory($bmi);

// Перевірити чи є активне тренування
$activeWorkout = getActiveWorkout($userId);

$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Головна - Фітнес Платформа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>

    <div class="container my-5">
        <h2 class="mb-4">Вітаємо, <?= e(explode('@', $profile['email'])[0]) ?>!</h2>

        <div class="row g-4">
            <!-- Статистика карток -->
            <div class="col-md-3">
                <div class="card stat-card bg-primary text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-2 opacity-75">Поточна вага</h6>
                        <h3 class="card-title mb-0"><?= number_format($profile['weight'], 1) ?> кг</h3>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card stat-card bg-success text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-2 opacity-75">ІМТ</h6>
                        <h3 class="card-title mb-0"><?= $bmi ?></h3>
                        <small><?= e($bmiCategory) ?></small>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card stat-card bg-info text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-2 opacity-75">Тренувань (30 днів)</h6>
                        <h3 class="card-title mb-0"><?= $stats['workouts_count'] ?></h3>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card stat-card bg-warning text-white">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-2 opacity-75">Спалено калорій</h6>
                        <h3 class="card-title mb-0"><?= number_format($stats['total_calories'], 0) ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mt-2">
            <!-- Активне тренування / Генерація -->
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Тренування</h5>

                        <?php if ($activeWorkout): ?>
                            <div class="alert alert-success">
                                <h6 class="alert-heading">У вас є активне тренування!</h6>
                                <p class="mb-2">Кількість вправ: <?= count($activeWorkout['exercises']) ?></p>
                                <a href="/workout.php" class="btn btn-success">Перейти до тренування</a>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <p class="text-muted mb-4">Створіть персоналізоване тренування на сьогодні</p>
                                <form method="POST" action="/workout.php">
                                    <input type="hidden" name="action" value="generate">
                                    <button type="submit" class="btn btn-primary btn-lg">
                                        Створити тренування на сьогодні
                                    </button>
                                </form>
                            </div>
                        <?php endif; ?>

                        <?php if ($stats['last_workout']): ?>
                            <hr class="my-4">
                            <h6 class="mb-3">Останнє тренування</h6>
                            <div class="d-flex justify-content-between">
                                <div>
                                    <small class="text-muted">Дата:</small>
                                    <div><?= formatDate($stats['last_workout']['date']) ?></div>
                                </div>
                                <div>
                                    <small class="text-muted">Тривалість:</small>
                                    <div><?= $stats['last_workout']['duration'] ?> хв</div>
                                </div>
                                <div>
                                    <small class="text-muted">Калорій:</small>
                                    <div><?= number_format($stats['last_workout']['calories_burned'], 0) ?></div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Графік ваги -->
            <div class="col-lg-4">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Динаміка ваги</h5>

                        <?php if (!empty($stats['weight_history'])): ?>
                            <canvas id="weightChart" height="200"></canvas>

                            <script>
                                const weightData = <?= json_encode($stats['weight_history']) ?>;
                                const ctx = document.getElementById('weightChart').getContext('2d');
                                new Chart(ctx, {
                                    type: 'line',
                                    data: {
                                        labels: weightData.map(d => new Date(d.logged_at).toLocaleDateString('uk-UA', {day: 'numeric', month: 'short'})),
                                        datasets: [{
                                            label: 'Вага (кг)',
                                            data: weightData.map(d => d.weight),
                                            borderColor: 'rgb(75, 192, 192)',
                                            backgroundColor: 'rgba(75, 192, 192, 0.1)',
                                            tension: 0.3,
                                            fill: true
                                        }]
                                    },
                                    options: {
                                        responsive: true,
                                        maintainAspectRatio: false,
                                        plugins: {
                                            legend: {
                                                display: false
                                            }
                                        },
                                        scales: {
                                            y: {
                                                beginAtZero: false
                                            }
                                        }
                                    }
                                });
                            </script>
                        <?php else: ?>
                            <p class="text-muted text-center">Немає даних про вагу</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Інформаційні картки -->
        <div class="row g-4 mt-2">
            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <h6 class="card-title text-primary">Рівень підготовки</h6>
                        <p class="card-text">
                            <?php
                            $levels = [1 => 'Початківець', 2 => 'Середній', 3 => 'Просунутий'];
                            echo $levels[$profile['fitness_level']];
                            ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <h6 class="card-title text-primary">Цільова вага</h6>
                        <p class="card-text">
                            <?= $profile['goal_weight'] ? number_format($profile['goal_weight'], 1) . ' кг' : 'Не вказано' ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card shadow-sm h-100">
                    <div class="card-body">
                        <h6 class="card-title text-primary">Загальний час тренувань</h6>
                        <p class="card-text"><?= $stats['total_duration'] ?> хвилин</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>
