<?php
require_once __DIR__ . '/includes/config.php';
session_start();
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireAuth();

$userId = getCurrentUserId();
$db = new Database();

$error = '';
$success = '';

// Обробка форми додавання пульсу
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $bpm = intval($_POST['bpm'] ?? 0);
        $source = $_POST['source'] ?? 'manual';

        if ($bpm < 40 || $bpm > 220) {
            $error = 'Введіть коректне значення пульсу (40-220 уд/хв)';
        } else {
            $result = $db->execute(
                "INSERT INTO heart_rate_logs (user_id, bpm, source) VALUES (?, ?, ?)",
                [$userId, $bpm, $source]
            );

            if ($result) {
                $success = 'Пульс успішно збережено!';
            } else {
                $error = 'Помилка збереження даних';
            }
        }
    } elseif ($action === 'generate') {
        // Згенерувати випадковий пульс (для демонстрації)
        $randomBpm = rand(60, 160);
        $db->execute(
            "INSERT INTO heart_rate_logs (user_id, bpm, source) VALUES (?, ?, 'watch')",
            [$userId, $randomBpm]
        );
        $success = "Згенеровано випадковий пульс: $randomBpm уд/хв";
    }
}

// Отримати історію пульсу (останні 50 записів)
$heartRateHistory = $db->query(
    "SELECT * FROM heart_rate_logs WHERE user_id = ? ORDER BY timestamp DESC LIMIT 50",
    [$userId]
);

// Для графіка (останні 20)
$chartData = array_slice(array_reverse($heartRateHistory), -20);

// Статистика
$stats = [
    'avg' => 0,
    'min' => 0,
    'max' => 0,
    'last' => null
];

if (!empty($heartRateHistory)) {
    $bpmValues = array_column($heartRateHistory, 'bpm');
    $stats['avg'] = round(array_sum($bpmValues) / count($bpmValues));
    $stats['min'] = min($bpmValues);
    $stats['max'] = max($bpmValues);
    $stats['last'] = $heartRateHistory[0];
}

$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Моніторинг пульсу - Фітнес Платформа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>

    <div class="container my-5">
        <h2 class="mb-4">Моніторинг пульсу</h2>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= e($success) ?></div>
        <?php endif; ?>

        <!-- Статистика -->
        <div class="row g-4 mb-4">
            <div class="col-md-3">
                <div class="card stat-card bg-danger text-white">
                    <div class="card-body text-center">
                        <h6 class="opacity-75">Останній пульс</h6>
                        <h2><?= $stats['last'] ? $stats['last']['bpm'] : '-' ?></h2>
                        <small><?= $stats['last'] ? formatDate($stats['last']['timestamp'], 'd.m.Y H:i') : '' ?></small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-primary text-white">
                    <div class="card-body text-center">
                        <h6 class="opacity-75">Середній</h6>
                        <h2><?= $stats['avg'] ?: '-' ?></h2>
                        <small>уд/хв</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-success text-white">
                    <div class="card-body text-center">
                        <h6 class="opacity-75">Мінімальний</h6>
                        <h2><?= $stats['min'] ?: '-' ?></h2>
                        <small>уд/хв</small>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card stat-card bg-warning text-white">
                    <div class="card-body text-center">
                        <h6 class="opacity-75">Максимальний</h6>
                        <h2><?= $stats['max'] ?: '-' ?></h2>
                        <small>уд/хв</small>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Графік -->
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Динаміка пульсу</h5>
                        <?php if (!empty($chartData)): ?>
                            <canvas id="heartRateChart" height="80"></canvas>

                            <script>
                                const hrData = <?= json_encode($chartData) ?>;
                                const ctx = document.getElementById('heartRateChart').getContext('2d');
                                new Chart(ctx, {
                                    type: 'line',
                                    data: {
                                        labels: hrData.map(d => new Date(d.timestamp).toLocaleString('uk-UA', {
                                            day: '2-digit',
                                            month: '2-digit',
                                            hour: '2-digit',
                                            minute: '2-digit'
                                        })),
                                        datasets: [{
                                            label: 'Пульс (уд/хв)',
                                            data: hrData.map(d => d.bpm),
                                            borderColor: 'rgb(220, 53, 69)',
                                            backgroundColor: 'rgba(220, 53, 69, 0.1)',
                                            tension: 0.3,
                                            fill: true,
                                            pointRadius: 4,
                                            pointHoverRadius: 6,
                                            pointBackgroundColor: hrData.map(d => d.source === 'watch' ? 'rgb(13, 110, 253)' : 'rgb(220, 53, 69)')
                                        }]
                                    },
                                    options: {
                                        responsive: true,
                                        maintainAspectRatio: false,
                                        plugins: {
                                            legend: {
                                                display: true
                                            },
                                            tooltip: {
                                                callbacks: {
                                                    afterLabel: function(context) {
                                                        const index = context.dataIndex;
                                                        const source = hrData[index].source;
                                                        return 'Джерело: ' + (source === 'manual' ? 'вручну' : 'трекер');
                                                    }
                                                }
                                            }
                                        },
                                        scales: {
                                            y: {
                                                beginAtZero: false,
                                                title: {
                                                    display: true,
                                                    text: 'Пульс (уд/хв)'
                                                },
                                                min: 40
                                            }
                                        }
                                    }
                                });
                            </script>
                        <?php else: ?>
                            <p class="text-muted text-center py-5">Немає даних для відображення</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Форма додавання -->
            <div class="col-lg-4">
                <div class="card shadow">
                    <div class="card-body">
                        <h5 class="card-title mb-4">Додати вимірювання</h5>

                        <form method="POST" action="">
                            <input type="hidden" name="action" value="add">

                            <div class="mb-3">
                                <label for="bpm" class="form-label">Пульс (уд/хв)</label>
                                <input type="number" class="form-control form-control-lg text-center"
                                       id="bpm" name="bpm" min="40" max="220" required
                                       placeholder="72">
                            </div>

                            <div class="mb-3">
                                <label for="source" class="form-label">Джерело</label>
                                <select class="form-select" id="source" name="source">
                                    <option value="manual">Вручну</option>
                                    <option value="watch">Фітнес-трекер</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-danger w-100 mb-2">Зберегти</button>
                        </form>

                        <form method="POST" action="">
                            <input type="hidden" name="action" value="generate">
                            <button type="submit" class="btn btn-outline-secondary w-100">
                                Згенерувати випадковий
                            </button>
                        </form>

                        <hr class="my-4">

                        <div class="alert alert-info small mb-0">
                            <strong>Зони пульсу:</strong><br>
                            Спокій: 60-100<br>
                            Розминка: 100-120<br>
                            Жиросжігання: 120-140<br>
                            Кардіо: 140-160<br>
                            Пікова: 160+
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Історія -->
        <div class="card shadow mt-4">
            <div class="card-body">
                <h5 class="card-title mb-4">Історія вимірювань</h5>

                <?php if (!empty($heartRateHistory)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Дата та час</th>
                                    <th>Пульс (уд/хв)</th>
                                    <th>Джерело</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach (array_slice($heartRateHistory, 0, 20) as $log): ?>
                                    <tr>
                                        <td><?= formatDate($log['timestamp'], 'd.m.Y H:i:s') ?></td>
                                        <td>
                                            <strong class="<?= $log['bpm'] > 160 ? 'text-danger' : ($log['bpm'] > 120 ? 'text-warning' : 'text-success') ?>">
                                                <?= $log['bpm'] ?>
                                            </strong>
                                        </td>
                                        <td>
                                            <span class="badge bg-<?= $log['source'] === 'manual' ? 'secondary' : 'primary' ?>">
                                                <?= $log['source'] === 'manual' ? 'Вручну' : 'Трекер' ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center py-4">Ще немає вимірювань пульсу</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>
