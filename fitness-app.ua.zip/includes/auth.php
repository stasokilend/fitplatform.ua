<?php
/**
 * Функції для роботи з автентифікацією та авторизацією
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

/**
 * Перевірити, чи користувач авторизований
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Отримати ID поточного користувача
 * @return int|null
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Отримати дані поточного користувача
 * @return array|null
 */
function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }

    $db = new Database();
    $user = $db->fetchOne(
        "SELECT id, email, role FROM users WHERE id = ?",
        [$_SESSION['user_id']]
    );

    return $user;
}

/**
 * Перевірити роль користувача
 * @param string|array $roles Роль або масив ролей
 * @return bool
 */
function hasRole($roles) {
    $user = getCurrentUser();
    if (!$user) {
        return false;
    }

    if (is_array($roles)) {
        return in_array($user['role'], $roles);
    }

    return $user['role'] === $roles;
}

/**
 * Вимагати авторизацію (редірект на login якщо не авторизований)
 */
function requireAuth() {
    if (!isLoggedIn()) {
        header('Location: /login.php');
        exit;
    }
}

/**
 * Вимагати певну роль
 * @param string|array $roles Роль або масив ролей
 */
function requireRole($roles) {
    requireAuth();

    if (!hasRole($roles)) {
        header('Location: /dashboard.php');
        exit;
    }
}

/**
 * Авторизувати користувача
 * @param int $userId ID користувача
 * @param string $email Email користувача
 * @param string $role Роль користувача
 */
function login($userId, $email, $role) {
    // Регенерація ID сесії для безпеки
    session_regenerate_id(true);

    $_SESSION['user_id'] = $userId;
    $_SESSION['email'] = $email;
    $_SESSION['role'] = $role;
}

/**
 * Вийти з системи
 */
function logout() {
    $_SESSION = [];

    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }

    session_destroy();
}

/**
 * Перевірити чи заповнений профіль користувача
 * @param int $userId ID користувача
 * @return bool
 */
function hasProfile($userId) {
    $db = new Database();
    $profile = $db->fetchOne(
        "SELECT id FROM user_profiles WHERE user_id = ?",
        [$userId]
    );

    return $profile !== null;
}

/**
 * Захист від CSRF (перевірка referer)
 * @return bool
 */
function verifyCsrf() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        $host = $_SERVER['HTTP_HOST'] ?? '';

        if (strpos($referer, $host) === false && !empty($host)) {
            return false;
        }
    }
    return true;
}
