<?php
/**
 * Конфігураційний файл бази даних
 * Налаштуйте параметри підключення відповідно до вашого середовища OpenServer
 */

// Налаштування сесії (до session_start!)
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_secure', 0); // Встановіть 1 якщо використовуєте HTTPS
}

// Параметри підключення до бази даних
define('DB_HOST', '127.0.1.31');
define('DB_NAME', 'fitness_db');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

// Часова зона
date_default_timezone_set('Europe/Kiev');

// Режим розробки (встановіть false для продакшн)
define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}
