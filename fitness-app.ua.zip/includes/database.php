<?php
/**
 * Клас для роботи з базою даних
 * Використовує PDO для безпечних запитів
 */

class Database {
    private $connection = null;

    /**
     * Отримати з'єднання з базою даних
     * @return PDO|null
     */
    public function getConnection() {
        if ($this->connection === null) {
            try {
                $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ];

                $this->connection = new PDO($dsn, DB_USER, DB_PASS, $options);
            } catch (PDOException $e) {
                if (DEBUG_MODE) {
                    die("Помилка підключення до БД: " . $e->getMessage());
                } else {
                    die("Помилка підключення до бази даних. Зверніться до адміністратора.");
                }
            }
        }

        return $this->connection;
    }

    /**
     * Виконати запит SELECT
     * @param string $query SQL запит
     * @param array $params Параметри для підстановки
     * @return array Масив результатів
     */
    public function query($query, $params = []) {
        try {
            $stmt = $this->getConnection()->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            if (DEBUG_MODE) {
                die("Помилка запиту: " . $e->getMessage());
            }
            return [];
        }
    }

    /**
     * Виконати INSERT/UPDATE/DELETE запит
     * @param string $query SQL запит
     * @param array $params Параметри для підстановки
     * @return bool|int ID останнього вставленого рядка або true при успіху
     */
    public function execute($query, $params = []) {
        try {
            $stmt = $this->getConnection()->prepare($query);
            $result = $stmt->execute($params);

            // Якщо це INSERT, повертаємо ID
            if (strpos(strtoupper($query), 'INSERT') === 0) {
                return $this->getConnection()->lastInsertId();
            }

            return $result;
        } catch (PDOException $e) {
            if (DEBUG_MODE) {
                die("Помилка виконання запиту: " . $e->getMessage());
            }
            return false;
        }
    }

    /**
     * Отримати один рядок результату
     * @param string $query SQL запит
     * @param array $params Параметри для підстановки
     * @return array|null
     */
    public function fetchOne($query, $params = []) {
        try {
            $stmt = $this->getConnection()->prepare($query);
            $stmt->execute($params);
            $result = $stmt->fetch();
            return $result ?: null;
        } catch (PDOException $e) {
            if (DEBUG_MODE) {
                die("Помилка запиту: " . $e->getMessage());
            }
            return null;
        }
    }
}
