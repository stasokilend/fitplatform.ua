<?php
/**
 * Допоміжні функції для роботи платформи
 */

require_once __DIR__ . '/database.php';

/**
 * Розрахувати ІМТ (Індекс маси тіла)
 * @param float $weight Вага в кг
 * @param int $height Зріст в см
 * @return float
 */
function calculateBMI($weight, $height) {
    $heightInMeters = $height / 100;
    return round($weight / ($heightInMeters * $heightInMeters), 2);
}

/**
 * Отримати категорію ІМТ
 * @param float $bmi ІМТ
 * @return string
 */
function getBMICategory($bmi) {
    if ($bmi < 18.5) return 'Недостатня вага';
    if ($bmi < 25) return 'Нормальна вага';
    if ($bmi < 30) return 'Надлишкова вага';
    return 'Ожиріння';
}

/**
 * Розрахувати базовий метаболізм (BMR) за формулою Міффліна-Сан Жеора
 * @param string $gender Стать (male/female)
 * @param int $age Вік
 * @param float $weight Вага в кг
 * @param int $height Зріст в см
 * @return float Калорій на день
 */
function calculateBMR($gender, $age, $weight, $height) {
    if ($gender === 'male') {
        return 10 * $weight + 6.25 * $height - 5 * $age + 5;
    } else {
        return 10 * $weight + 6.25 * $height - 5 * $age - 161;
    }
}

/**
 * Розрахувати денну норму калорій з урахуванням рівня активності
 * @param float $bmr Базовий метаболізм
 * @param int $fitnessLevel Рівень підготовки (1-3)
 * @return float
 */
function calculateDailyCalories($bmr, $fitnessLevel) {
    $activityMultiplier = [
        1 => 1.375, // Початківець (легка активність)
        2 => 1.55,  // Середній (помірна активність)
        3 => 1.725  // Просунутий (висока активність)
    ];

    return round($bmr * ($activityMultiplier[$fitnessLevel] ?? 1.375));
}

/**
 * Генерувати персоналізоване тренування (жадібний алгоритм)
 * @param int $userId ID користувача
 * @return array|null ID створеного плану або null при помилці
 */
function generateWorkout($userId) {
    $db = new Database();

    // Отримати профіль користувача
    $profile = $db->fetchOne(
        "SELECT up.*, u.email
         FROM user_profiles up
         JOIN users u ON u.id = up.user_id
         WHERE up.user_id = ?",
        [$userId]
    );

    if (!$profile) {
        return null;
    }

    // Отримати обмеження користувача
    $restrictions = $db->query(
        "SELECT restriction_id FROM user_restrictions WHERE user_id = ?",
        [$userId]
    );
    $restrictionIds = array_column($restrictions, 'restriction_id');

    // Отримати доступні вправи (які не конфліктують з обмеженнями)
    $allExercises = $db->query(
        "SELECT * FROM exercises WHERE difficulty <= ? ORDER BY difficulty, calories_per_min DESC",
        [$profile['fitness_level']]
    );

    // Фільтрувати вправи за обмеженнями
    $availableExercises = [];
    foreach ($allExercises as $exercise) {
        $exerciseRestrictions = json_decode($exercise['restrictions'], true) ?? [];

        // Перевірити чи вправа конфліктує з обмеженнями користувача
        $hasConflict = false;
        foreach ($restrictionIds as $userRestriction) {
            if (in_array($userRestriction, $exerciseRestrictions)) {
                $hasConflict = true;
                break;
            }
        }

        if (!$hasConflict) {
            $availableExercises[] = $exercise;
        }
    }

    if (empty($availableExercises)) {
        return null;
    }

    // Парсити пріоритети цілей
    $goalPriority = json_decode($profile['goal_priority'], true) ?? [
        'weight_loss' => 0.5,
        'muscle_gain' => 0.3,
        'endurance' => 0.2
    ];

    // Розрахувати цільовий час тренування (залежить від рівня)
    $targetDuration = [
        1 => 25, // Початківець
        2 => 35, // Середній
        3 => 45  // Просунутий
    ][$profile['fitness_level']];

    // Жадібний алгоритм вибору вправ
    $selectedExercises = [];
    $totalDuration = 0;
    $usedExercises = [];

    // Сортувати вправи за ефективністю відповідно до цілей
    usort($availableExercises, function($a, $b) use ($goalPriority) {
        // Вагова оцінка вправи
        $scoreA = $a['calories_per_min'] * ($goalPriority['weight_loss'] ?? 0) +
                  $a['met_value'] * ($goalPriority['endurance'] ?? 0) +
                  $a['difficulty'] * 2 * ($goalPriority['muscle_gain'] ?? 0);

        $scoreB = $b['calories_per_min'] * ($goalPriority['weight_loss'] ?? 0) +
                  $b['met_value'] * ($goalPriority['endurance'] ?? 0) +
                  $b['difficulty'] * 2 * ($goalPriority['muscle_gain'] ?? 0);

        return $scoreB <=> $scoreA;
    });

    // Вибрати 5-7 вправ
    $maxExercises = rand(5, 7);
    foreach ($availableExercises as $exercise) {
        if (count($selectedExercises) >= $maxExercises) {
            break;
        }

        if ($totalDuration + $exercise['duration'] <= $targetDuration + 5) {
            $selectedExercises[] = $exercise;
            $totalDuration += $exercise['duration'];
        }
    }

    if (empty($selectedExercises)) {
        return null;
    }

    // Створити план тренування
    $planId = $db->execute(
        "INSERT INTO workout_plans (user_id, start_date, status) VALUES (?, CURDATE(), 'active')",
        [$userId]
    );

    if (!$planId) {
        return null;
    }

    // Деактивувати попередні активні плани
    $db->execute(
        "UPDATE workout_plans SET status = 'cancelled' WHERE user_id = ? AND id != ? AND status = 'active'",
        [$userId, $planId]
    );

    // Створити сесію тренування
    $sessionId = $db->execute(
        "INSERT INTO workout_sessions (plan_id, session_date) VALUES (?, NOW())",
        [$planId]
    );

    if (!$sessionId) {
        return null;
    }

    // Додати вправи до тренування
    foreach ($selectedExercises as $exercise) {
        // Розрахувати рекомендовану кількість підходів та повторень залежно від рівня
        $sets = [
            1 => 2,  // Початківець
            2 => 3,  // Середній
            3 => 4   // Просунутий
        ][$profile['fitness_level']];

        $reps = [
            1 => 10,  // Початківець
            2 => 12,  // Середній
            3 => 15   // Просунутий
        ][$profile['fitness_level']];

        $db->execute(
            "INSERT INTO session_exercises (session_id, exercise_id, sets, reps, completed) VALUES (?, ?, ?, ?, 0)",
            [$sessionId, $exercise['id'], $sets, $reps]
        );
    }

    return [
        'plan_id' => $planId,
        'session_id' => $sessionId,
        'exercises' => $selectedExercises,
        'total_duration' => $totalDuration
    ];
}

/**
 * Отримати активне тренування користувача
 * @param int $userId ID користувача
 * @return array|null
 */
function getActiveWorkout($userId) {
    $db = new Database();

    // Знайти активний план
    $plan = $db->fetchOne(
        "SELECT * FROM workout_plans WHERE user_id = ? AND status = 'active' ORDER BY created_at DESC LIMIT 1",
        [$userId]
    );

    if (!$plan) {
        return null;
    }

    // Знайти останню незавершену сесію
    $session = $db->fetchOne(
        "SELECT * FROM workout_sessions WHERE plan_id = ? AND completed_at IS NULL ORDER BY session_date DESC LIMIT 1",
        [$plan['id']]
    );

    if (!$session) {
        return null;
    }

    // Отримати вправи з деталями
    $exercises = $db->query(
        "SELECT se.*, e.name, e.description, e.duration, e.calories_per_min, e.met_value, e.muscle_groups
         FROM session_exercises se
         JOIN exercises e ON e.id = se.exercise_id
         WHERE se.session_id = ?
         ORDER BY se.id",
        [$session['id']]
    );

    return [
        'plan' => $plan,
        'session' => $session,
        'exercises' => $exercises
    ];
}

/**
 * Завершити тренування
 * @param int $sessionId ID сесії
 * @param int $userId ID користувача
 * @return bool
 */
function completeWorkout($sessionId, $userId) {
    $db = new Database();

    // Перевірити що сесія належить користувачеві
    $session = $db->fetchOne(
        "SELECT ws.*, wp.user_id
         FROM workout_sessions ws
         JOIN workout_plans wp ON wp.id = ws.plan_id
         WHERE ws.id = ? AND wp.user_id = ?",
        [$sessionId, $userId]
    );

    if (!$session) {
        return false;
    }

    // Отримати вправи та розрахувати спалені калорії
    $exercises = $db->query(
        "SELECT se.*, e.calories_per_min, e.duration, e.met_value
         FROM session_exercises se
         JOIN exercises e ON e.id = se.exercise_id
         WHERE se.session_id = ? AND se.completed = 1",
        [$sessionId]
    );

    $totalCalories = 0;
    $totalDuration = 0;

    foreach ($exercises as $ex) {
        $duration = $ex['duration'];
        $totalCalories += $ex['calories_per_min'] * $duration;
        $totalDuration += $duration;
    }

    // Оновити сесію
    $result = $db->execute(
        "UPDATE workout_sessions SET duration = ?, calories_burned = ?, completed_at = NOW() WHERE id = ?",
        [$totalDuration, $totalCalories, $sessionId]
    );

    return $result !== false;
}

/**
 * Отримати статистику користувача
 * @param int $userId ID користувача
 * @param int $days Кількість днів для аналізу
 * @return array
 */
function getUserStats($userId, $days = 30) {
    $db = new Database();

    // Кількість тренувань
    $workoutsCount = $db->fetchOne(
        "SELECT COUNT(*) as count
         FROM workout_sessions ws
         JOIN workout_plans wp ON wp.id = ws.plan_id
         WHERE wp.user_id = ? AND ws.completed_at IS NOT NULL AND ws.completed_at >= DATE_SUB(NOW(), INTERVAL ? DAY)",
        [$userId, $days]
    )['count'] ?? 0;

    // Загальна кількість калорій
    $totalCalories = $db->fetchOne(
        "SELECT SUM(ws.calories_burned) as total
         FROM workout_sessions ws
         JOIN workout_plans wp ON wp.id = ws.plan_id
         WHERE wp.user_id = ? AND ws.completed_at IS NOT NULL AND ws.completed_at >= DATE_SUB(NOW(), INTERVAL ? DAY)",
        [$userId, $days]
    )['total'] ?? 0;

    // Загальний час тренувань
    $totalDuration = $db->fetchOne(
        "SELECT SUM(ws.duration) as total
         FROM workout_sessions ws
         JOIN workout_plans wp ON wp.id = ws.plan_id
         WHERE wp.user_id = ? AND ws.completed_at IS NOT NULL AND ws.completed_at >= DATE_SUB(NOW(), INTERVAL ? DAY)",
        [$userId, $days]
    )['total'] ?? 0;

    // Останнє тренування
    $lastWorkout = $db->fetchOne(
        "SELECT ws.*, ws.completed_at as date
         FROM workout_sessions ws
         JOIN workout_plans wp ON wp.id = ws.plan_id
         WHERE wp.user_id = ? AND ws.completed_at IS NOT NULL
         ORDER BY ws.completed_at DESC LIMIT 1",
        [$userId]
    );

    // Історія ваги
    $weightHistory = $db->query(
        "SELECT weight, logged_at FROM weight_logs WHERE user_id = ? ORDER BY logged_at DESC LIMIT 10",
        [$userId]
    );

    return [
        'workouts_count' => $workoutsCount,
        'total_calories' => round($totalCalories, 2),
        'total_duration' => $totalDuration,
        'last_workout' => $lastWorkout,
        'weight_history' => array_reverse($weightHistory)
    ];
}

/**
 * Безпечний вивід HTML
 * @param string $text Текст
 * @return string
 */
function e($text) {
    return htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
}

/**
 * Форматувати дату
 * @param string $date Дата
 * @param string $format Формат
 * @return string
 */
function formatDate($date, $format = 'd.m.Y H:i') {
    if (!$date) return '';
    $timestamp = strtotime($date);
    return date($format, $timestamp);
}
