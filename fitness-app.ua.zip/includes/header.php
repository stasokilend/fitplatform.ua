<?php
$currentPage = basename($_SERVER['PHP_SELF']);
$user = getCurrentUser();
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
        <a class="navbar-brand" href="/dashboard.php">
            <strong>Фітнес Платформа</strong>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>" href="/dashboard.php">Головна</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'workout.php' ? 'active' : '' ?>" href="/workout.php">Моє тренування</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'statistics.php' ? 'active' : '' ?>" href="/statistics.php">Статистика</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'heart_rate.php' ? 'active' : '' ?>" href="/heart_rate.php">Пульс</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentPage === 'profile.php' ? 'active' : '' ?>" href="/profile.php">Профіль</a>
                </li>
                <?php if ($user && $user['role'] === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="/admin/">Адмін-панель</a>
                </li>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                        <?= e($user['email']) ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="/profile.php">Налаштування</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/logout.php">Вихід</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>
