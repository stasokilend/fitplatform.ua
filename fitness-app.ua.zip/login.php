<?php
require_once __DIR__ . '/includes/config.php';
session_start();
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';

$error = '';
$success = '';

// Якщо вже авторизований - редірект
if (isLoggedIn()) {
    header('Location: /dashboard.php');
    exit;
}

// Обробка форми
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Валідація
    if (empty($email) || empty($password)) {
        $error = 'Заповніть усі поля';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Невірний формат email';
    } else {
        // Перевірка в БД
        $db = new Database();
        $user = $db->fetchOne(
            "SELECT id, email, password_hash, role FROM users WHERE email = ?",
            [$email]
        );

        if ($user && password_verify($password, $user['password_hash'])) {
            // Успішна авторизація
            login($user['id'], $user['email'], $user['role']);

            // Перевірити чи є профіль
            if (hasProfile($user['id'])) {
                header('Location: /dashboard.php');
            } else {
                header('Location: /profile.php');
            }
            exit;
        } else {
            $error = 'Невірний email або пароль';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вхід - Фітнес Платформа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body class="auth-page">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-5">
                <div class="card shadow-lg">
                    <div class="card-body p-5">
                        <h2 class="text-center mb-4">Вхід до системи</h2>

                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= e($error) ?></div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="alert alert-success"><?= e($success) ?></div>
                        <?php endif; ?>

                        <form method="POST" action="" id="loginForm">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email"
                                       value="<?= e($_POST['email'] ?? '') ?>" required>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Пароль</label>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 mb-3">Увійти</button>
                        </form>

                        <div class="text-center">
                            <p class="mb-0">Ще не зареєстровані? <a href="/register.php">Створити акаунт</a></p>
                        </div>

                        <hr class="my-4">

                        <div class="text-center text-muted small">
                            <p class="mb-1">Тестові облікові записи:</p>
                            <p class="mb-0">Користувач: user@test.com / password123</p>
                            <p class="mb-0">Адмін: admin@test.com / password123</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>
