<?php
require_once __DIR__ . '/includes/config.php';
session_start();
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireAuth();

$userId = getCurrentUserId();
$db = new Database();

$error = '';
$success = '';

// Перевірити чи профіль вже існує
$existingProfile = $db->fetchOne(
    "SELECT * FROM user_profiles WHERE user_id = ?",
    [$userId]
);

// Отримати список обмежень
$allRestrictions = $db->query("SELECT * FROM medical_restrictions ORDER BY name");

// Обробка форми
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gender = $_POST['gender'] ?? '';
    $age = intval($_POST['age'] ?? 0);
    $weight = floatval($_POST['weight'] ?? 0);
    $height = intval($_POST['height'] ?? 0);
    $goalWeight = floatval($_POST['goal_weight'] ?? 0);
    $fitnessLevel = intval($_POST['fitness_level'] ?? 1);
    $restrictions = $_POST['restrictions'] ?? [];

    // Пріоритети цілей
    $weightLoss = floatval($_POST['weight_loss'] ?? 0.5);
    $muscleGain = floatval($_POST['muscle_gain'] ?? 0.3);
    $endurance = floatval($_POST['endurance'] ?? 0.2);

    // Нормалізувати пріоритети (сума = 1)
    $total = $weightLoss + $muscleGain + $endurance;
    if ($total > 0) {
        $weightLoss /= $total;
        $muscleGain /= $total;
        $endurance /= $total;
    }

    $goalPriority = json_encode([
        'weight_loss' => round($weightLoss, 2),
        'muscle_gain' => round($muscleGain, 2),
        'endurance' => round($endurance, 2)
    ]);

    // Валідація
    if (empty($gender) || $age < 10 || $age > 120) {
        $error = 'Вкажіть правильний вік (10-120 років)';
    } elseif ($weight < 30 || $weight > 300) {
        $error = 'Вкажіть правильну вагу (30-300 кг)';
    } elseif ($height < 100 || $height > 250) {
        $error = 'Вкажіть правильний зріст (100-250 см)';
    } elseif ($goalWeight > 0 && ($goalWeight < 30 || $goalWeight > 300)) {
        $error = 'Вкажіть правильну цільову вагу (30-300 кг)';
    } else {
        // Зберегти або оновити профіль
        if ($existingProfile) {
            // Оновити
            $result = $db->execute(
                "UPDATE user_profiles SET gender = ?, age = ?, weight = ?, height = ?,
                 goal_weight = ?, fitness_level = ?, goal_priority = ?, updated_at = NOW()
                 WHERE user_id = ?",
                [$gender, $age, $weight, $height, $goalWeight, $fitnessLevel, $goalPriority, $userId]
            );
        } else {
            // Створити
            $result = $db->execute(
                "INSERT INTO user_profiles (user_id, gender, age, weight, height, goal_weight, fitness_level, goal_priority)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                [$userId, $gender, $age, $weight, $height, $goalWeight, $fitnessLevel, $goalPriority]
            );

            // Додати запис в історію ваги
            $db->execute(
                "INSERT INTO weight_logs (user_id, weight) VALUES (?, ?)",
                [$userId, $weight]
            );
        }

        if ($result !== false) {
            // Оновити обмеження
            // Спочатку видалити старі
            $db->execute("DELETE FROM user_restrictions WHERE user_id = ?", [$userId]);

            // Додати нові
            foreach ($restrictions as $restrictionId) {
                $db->execute(
                    "INSERT INTO user_restrictions (user_id, restriction_id) VALUES (?, ?)",
                    [$userId, intval($restrictionId)]
                );
            }

            $success = 'Профіль успішно збережено!';
            header('Location: /dashboard.php');
            exit;
        } else {
            $error = 'Помилка збереження профілю';
        }
    }
}

// Отримати поточні обмеження користувача
$userRestrictions = $db->query(
    "SELECT restriction_id FROM user_restrictions WHERE user_id = ?",
    [$userId]
);
$userRestrictionIds = array_column($userRestrictions, 'restriction_id');

$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мій профіль - Фітнес Платформа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-body p-4">
                        <h2 class="mb-4"><?= $existingProfile ? 'Редагувати профіль' : 'Заповнити профіль' ?></h2>

                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= e($error) ?></div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="alert alert-success"><?= e($success) ?></div>
                        <?php endif; ?>

                        <?php if (!$existingProfile): ?>
                            <div class="alert alert-info">
                                Заповніть ваші дані для персоналізованих тренувань
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="" id="profileForm">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="gender" class="form-label">Стать <span class="text-danger">*</span></label>
                                    <select class="form-select" id="gender" name="gender" required>
                                        <option value="">Оберіть...</option>
                                        <option value="male" <?= ($existingProfile['gender'] ?? '') === 'male' ? 'selected' : '' ?>>Чоловіча</option>
                                        <option value="female" <?= ($existingProfile['gender'] ?? '') === 'female' ? 'selected' : '' ?>>Жіноча</option>
                                    </select>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="age" class="form-label">Вік <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="age" name="age"
                                           value="<?= e($existingProfile['age'] ?? '') ?>"
                                           min="10" max="120" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label for="weight" class="form-label">Вага (кг) <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="weight" name="weight"
                                           value="<?= e($existingProfile['weight'] ?? '') ?>"
                                           min="30" max="300" step="0.1" required>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label for="height" class="form-label">Зріст (см) <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="height" name="height"
                                           value="<?= e($existingProfile['height'] ?? '') ?>"
                                           min="100" max="250" required>
                                </div>

                                <div class="col-md-4 mb-3">
                                    <label for="goal_weight" class="form-label">Цільова вага (кг)</label>
                                    <input type="number" class="form-control" id="goal_weight" name="goal_weight"
                                           value="<?= e($existingProfile['goal_weight'] ?? '') ?>"
                                           min="30" max="300" step="0.1">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="fitness_level" class="form-label">Рівень підготовки <span class="text-danger">*</span></label>
                                <select class="form-select" id="fitness_level" name="fitness_level" required>
                                    <option value="1" <?= ($existingProfile['fitness_level'] ?? 1) == 1 ? 'selected' : '' ?>>Початківець</option>
                                    <option value="2" <?= ($existingProfile['fitness_level'] ?? 1) == 2 ? 'selected' : '' ?>>Середній</option>
                                    <option value="3" <?= ($existingProfile['fitness_level'] ?? 1) == 3 ? 'selected' : '' ?>>Просунутий</option>
                                </select>
                            </div>

                            <hr class="my-4">

                            <h5 class="mb-3">Пріоритети цілей</h5>
                            <p class="text-muted small">Вкажіть важливість кожної цілі (автоматично нормалізується до 100%)</p>

                            <?php
                            $priorities = $existingProfile ? json_decode($existingProfile['goal_priority'], true) : [
                                'weight_loss' => 0.5,
                                'muscle_gain' => 0.3,
                                'endurance' => 0.2
                            ];
                            ?>

                            <div class="mb-3">
                                <label for="weight_loss" class="form-label">
                                    Схуднення: <span id="weight_loss_value"><?= round($priorities['weight_loss'] * 100) ?>%</span>
                                </label>
                                <input type="range" class="form-range priority-slider" id="weight_loss" name="weight_loss"
                                       min="0" max="100" value="<?= round($priorities['weight_loss'] * 100) ?>">
                            </div>

                            <div class="mb-3">
                                <label for="muscle_gain" class="form-label">
                                    Набір м'язової маси: <span id="muscle_gain_value"><?= round($priorities['muscle_gain'] * 100) ?>%</span>
                                </label>
                                <input type="range" class="form-range priority-slider" id="muscle_gain" name="muscle_gain"
                                       min="0" max="100" value="<?= round($priorities['muscle_gain'] * 100) ?>">
                            </div>

                            <div class="mb-3">
                                <label for="endurance" class="form-label">
                                    Витривалість: <span id="endurance_value"><?= round($priorities['endurance'] * 100) ?>%</span>
                                </label>
                                <input type="range" class="form-range priority-slider" id="endurance" name="endurance"
                                       min="0" max="100" value="<?= round($priorities['endurance'] * 100) ?>">
                            </div>

                            <hr class="my-4">

                            <h5 class="mb-3">Медичні обмеження</h5>
                            <p class="text-muted small">Оберіть обмеження, які враховуватимуться при підборі вправ</p>

                            <?php foreach ($allRestrictions as $restriction): ?>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="restrictions[]"
                                           value="<?= $restriction['id'] ?>" id="restriction_<?= $restriction['id'] ?>"
                                           <?= in_array($restriction['id'], $userRestrictionIds) ? 'checked' : '' ?>>
                                    <label class="form-check-label" for="restriction_<?= $restriction['id'] ?>">
                                        <strong><?= e($restriction['name']) ?></strong>
                                        <?php if ($restriction['description']): ?>
                                            <br><small class="text-muted"><?= e($restriction['description']) ?></small>
                                        <?php endif; ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>

                            <hr class="my-4">

                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg">Зберегти профіль</button>
                                <?php if ($existingProfile): ?>
                                    <a href="/dashboard.php" class="btn btn-outline-secondary">Скасувати</a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
    <script>
        // Оновлення значень слайдерів
        document.querySelectorAll('.priority-slider').forEach(slider => {
            slider.addEventListener('input', function() {
                document.getElementById(this.id + '_value').textContent = this.value + '%';
            });
        });
    </script>
</body>
</html>
