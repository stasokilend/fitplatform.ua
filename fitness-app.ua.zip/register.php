<?php
require_once __DIR__ . '/includes/config.php';
session_start();
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';

$error = '';
$success = '';

// Якщо вже авторизований - редірект
if (isLoggedIn()) {
    header('Location: /dashboard.php');
    exit;
}

// Обробка форми
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    // Валідація
    if (empty($email) || empty($password) || empty($password_confirm)) {
        $error = 'Заповніть усі поля';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Невірний формат email';
    } elseif (strlen($password) < 6) {
        $error = 'Пароль має містити мінімум 6 символів';
    } elseif ($password !== $password_confirm) {
        $error = 'Паролі не співпадають';
    } else {
        // Перевірити чи email вже існує
        $db = new Database();
        $existingUser = $db->fetchOne(
            "SELECT id FROM users WHERE email = ?",
            [$email]
        );

        if ($existingUser) {
            $error = 'Користувач з таким email вже існує';
        } else {
            // Створити користувача
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $userId = $db->execute(
                "INSERT INTO users (email, password_hash, role) VALUES (?, ?, 'user')",
                [$email, $passwordHash]
            );

            if ($userId) {
                // Авторизувати та перенаправити на заповнення профілю
                login($userId, $email, 'user');
                header('Location: /profile.php');
                exit;
            } else {
                $error = 'Помилка при створенні акаунта. Спробуйте ще раз.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Реєстрація - Фітнес Платформа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body class="auth-page">
    <div class="container">
        <div class="row justify-content-center align-items-center min-vh-100">
            <div class="col-md-5">
                <div class="card shadow-lg">
                    <div class="card-body p-5">
                        <h2 class="text-center mb-4">Реєстрація</h2>

                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?= e($error) ?></div>
                        <?php endif; ?>

                        <form method="POST" action="" id="registerForm">
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" name="email"
                                       value="<?= e($_POST['email'] ?? '') ?>" required>
                                <div class="form-text">Використовуйте дійсний email</div>
                            </div>

                            <div class="mb-3">
                                <label for="password" class="form-label">Пароль</label>
                                <input type="password" class="form-control" id="password" name="password"
                                       minlength="6" required>
                                <div class="form-text">Мінімум 6 символів</div>
                            </div>

                            <div class="mb-3">
                                <label for="password_confirm" class="form-label">Підтвердження пароля</label>
                                <input type="password" class="form-control" id="password_confirm"
                                       name="password_confirm" minlength="6" required>
                            </div>

                            <button type="submit" class="btn btn-primary w-100 mb-3">Зареєструватися</button>
                        </form>

                        <div class="text-center">
                            <p class="mb-0">Вже є акаунт? <a href="/login.php">Увійти</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
    <script>
        // Валідація співпадіння паролів
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const password = document.getElementById('password').value;
            const passwordConfirm = document.getElementById('password_confirm').value;

            if (password !== passwordConfirm) {
                e.preventDefault();
                alert('Паролі не співпадають');
            }
        });
    </script>
</body>
</html>
