-- ============================================
-- База даних для платформи персоналізованих тренувань
-- ============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- ============================================
-- Створення бази даних
-- ============================================
CREATE DATABASE IF NOT EXISTS `fitness_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `fitness_db`;

-- ============================================
-- Таблиця: users (користувачі)
-- ============================================
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('user','trainer','admin') NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Реєстраційні дані користувачів';

-- ============================================
-- Таблиця: user_profiles (профілі користувачів)
-- ============================================
CREATE TABLE `user_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `age` int(11) NOT NULL,
  `weight` decimal(5,2) NOT NULL COMMENT 'Вага в кг',
  `height` int(11) NOT NULL COMMENT 'Зріст в см',
  `goal_weight` decimal(5,2) DEFAULT NULL COMMENT 'Цільова вага в кг',
  `fitness_level` int(11) NOT NULL DEFAULT '1' COMMENT '1-початківець, 2-середній, 3-просунутий',
  `goal_priority` text COMMENT 'JSON з пріоритетами цілей',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `fk_user_profiles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Антропометричні дані користувачів';

-- ============================================
-- Таблиця: medical_restrictions (медичні обмеження)
-- ============================================
CREATE TABLE `medical_restrictions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT 'Назва українською',
  `description` text,
  PRIMARY KEY (`id`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Довідник медичних обмежень';

-- ============================================
-- Таблиця: user_restrictions (обмеження користувачів)
-- ============================================
CREATE TABLE `user_restrictions` (
  `user_id` int(11) NOT NULL,
  `restriction_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`restriction_id`),
  KEY `fk_restriction` (`restriction_id`),
  CONSTRAINT `fk_user_restrictions_restriction` FOREIGN KEY (`restriction_id`) REFERENCES `medical_restrictions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_user_restrictions_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Зв\'язок користувачів з обмеженнями';

-- ============================================
-- Таблиця: exercises (вправи)
-- ============================================
CREATE TABLE `exercises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT 'Назва українською',
  `description` text,
  `duration` int(11) NOT NULL DEFAULT '10' COMMENT 'Тривалість в хвилинах',
  `calories_per_min` decimal(5,2) NOT NULL DEFAULT '5.00' COMMENT 'Калорій за хвилину',
  `met_value` decimal(4,2) NOT NULL DEFAULT '3.00' COMMENT 'Метаболічний еквівалент',
  `difficulty` int(11) NOT NULL DEFAULT '1' COMMENT '1-легко, 2-середньо, 3-складно',
  `muscle_groups` text COMMENT 'JSON масив груп м\'язів',
  `restrictions` text COMMENT 'JSON масив ID обмежень, при яких вправа заборонена',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_difficulty` (`difficulty`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='База вправ';

-- ============================================
-- Таблиця: workout_plans (плани тренувань)
-- ============================================
CREATE TABLE `workout_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `fk_workout_plans_user` (`user_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_workout_plans_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Тренувальні плани';

-- ============================================
-- Таблиця: workout_sessions (тренування)
-- ============================================
CREATE TABLE `workout_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_id` int(11) NOT NULL,
  `session_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `duration` int(11) DEFAULT NULL COMMENT 'Тривалість в хвилинах',
  `calories_burned` decimal(7,2) DEFAULT NULL COMMENT 'Спалено калорій',
  `heart_rate_avg` int(11) DEFAULT NULL COMMENT 'Середній пульс',
  `notes` text,
  `completed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_workout_sessions_plan` (`plan_id`),
  CONSTRAINT `fk_workout_sessions_plan` FOREIGN KEY (`plan_id`) REFERENCES `workout_plans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Окремі тренування';

-- ============================================
-- Таблиця: session_exercises (вправи в тренуванні)
-- ============================================
CREATE TABLE `session_exercises` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session_id` int(11) NOT NULL,
  `exercise_id` int(11) NOT NULL,
  `sets` int(11) NOT NULL DEFAULT '3' COMMENT 'Кількість підходів',
  `reps` int(11) NOT NULL DEFAULT '10' COMMENT 'Кількість повторень',
  `weight` decimal(5,2) DEFAULT NULL COMMENT 'Вага в кг',
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_session_exercises_session` (`session_id`),
  KEY `fk_session_exercises_exercise` (`exercise_id`),
  CONSTRAINT `fk_session_exercises_exercise` FOREIGN KEY (`exercise_id`) REFERENCES `exercises` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_session_exercises_session` FOREIGN KEY (`session_id`) REFERENCES `workout_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Вправи в межах тренування';

-- ============================================
-- Таблиця: heart_rate_logs (журнал пульсу)
-- ============================================
CREATE TABLE `heart_rate_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `bpm` int(11) NOT NULL COMMENT 'Ударів за хвилину',
  `source` enum('manual','watch') NOT NULL DEFAULT 'manual',
  PRIMARY KEY (`id`),
  KEY `fk_heart_rate_logs_user` (`user_id`),
  KEY `idx_timestamp` (`timestamp`),
  CONSTRAINT `fk_heart_rate_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Дані пульсу користувачів';

-- ============================================
-- Таблиця: weight_logs (журнал ваги)
-- ============================================
CREATE TABLE `weight_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `weight` decimal(5,2) NOT NULL COMMENT 'Вага в кг',
  `logged_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_weight_logs_user` (`user_id`),
  KEY `idx_logged_at` (`logged_at`),
  CONSTRAINT `fk_weight_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Історія зміни ваги';

-- ============================================
-- ТЕСТОВІ ДАНІ
-- ============================================

-- Користувачі (паролі хешовані: password123 та admin123)
INSERT INTO `users` (`id`, `email`, `password_hash`, `role`, `created_at`) VALUES
(1, 'user@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'user', '2026-06-01 10:00:00'),
(2, 'admin@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '2026-06-01 10:00:00'),
(3, 'trainer@test.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'trainer', '2026-06-01 10:00:00');

-- Профілі користувачів
INSERT INTO `user_profiles` (`user_id`, `gender`, `age`, `weight`, `height`, `goal_weight`, `fitness_level`, `goal_priority`) VALUES
(1, 'male', 28, 85.50, 180, 78.00, 2, '{"weight_loss":0.7,"muscle_gain":0.2,"endurance":0.1}'),
(3, 'female', 32, 65.00, 168, 60.00, 3, '{"weight_loss":0.5,"muscle_gain":0.3,"endurance":0.2}');

-- Медичні обмеження
INSERT INTO `medical_restrictions` (`id`, `name`, `description`) VALUES
(1, 'Грижа хребта', 'Обмеження на вправи з осьовим навантаженням на хребет'),
(2, 'Гіпертонія', 'Обмеження на високоінтенсивні кардіо вправи'),
(3, 'Травма коліна', 'Обмеження на присідання, вистрибування та біг'),
(4, 'Проблеми з серцем', 'Обмеження на інтенсивні кардіо та анаеробні вправи');

-- Обмеження користувачів
INSERT INTO `user_restrictions` (`user_id`, `restriction_id`) VALUES
(1, 3);

-- База вправ (15 вправ з різними параметрами)
INSERT INTO `exercises` (`id`, `name`, `description`, `duration`, `calories_per_min`, `met_value`, `difficulty`, `muscle_groups`, `restrictions`) VALUES
(1, 'Присідання', 'Класичні присідання з власною вагою. Зміцнюють ноги та сідниці.', 5, 7.50, 5.00, 1, '["quadriceps","glutes","hamstrings"]', '[3]'),
(2, 'Віджимання від підлоги', 'Базова вправа для верхньої частини тіла. Розвиває груди, плечі та трицепси.', 5, 8.00, 3.80, 1, '["chest","triceps","shoulders"]', '[]'),
(3, 'Планка', 'Статична вправа для зміцнення кору. Тримати положення 30-60 секунд.', 3, 5.00, 3.00, 1, '["core","abs"]', '[]'),
(4, 'Випади вперед', 'Динамічна вправа для ніг та сідниць. По 10-12 повторень на кожну ногу.', 5, 7.00, 4.50, 2, '["quadriceps","glutes","hamstrings"]', '[3]'),
(5, 'Біг на місці', 'Кардіо вправа середньої інтенсивності. Підвищує витривалість та спалює калорії.', 10, 10.00, 8.00, 2, '["legs","cardio"]', '[2,3]'),
(6, 'Скручування на прес', 'Ізольована вправа для м\'язів живота. 15-20 повторень за підхід.', 4, 4.50, 3.50, 1, '["abs"]', '[]'),
(7, 'Стрибки з розведенням', 'Інтенсивна кардіо вправа. Jumping jacks для розминки та жиросжігання.', 5, 9.50, 7.50, 2, '["legs","shoulders","cardio"]', '[2,3,4]'),
(8, 'Підйоми на носки', 'Вправа для литкових м\'язів. 15-20 повторень за підхід.', 4, 4.00, 3.00, 1, '["calves"]', '[]'),
(9, 'Берпі', 'Високоінтенсивна комплексна вправа. Задіює все тіло.', 5, 12.00, 8.50, 3, '["full_body","cardio"]', '[1,2,4]'),
(10, 'Планка бічна', 'Статична вправа для бічних м\'язів кору. Тримати 20-40 секунд на кожну сторону.', 3, 5.50, 3.50, 2, '["core","obliques"]', '[]'),
(11, 'Розведення рук з гантелями', 'Вправа для плечей. Можна виконувати з легкими гантелями або без.', 5, 6.00, 4.00, 2, '["shoulders","chest"]', '[]'),
(12, 'Велосипед лежачи', 'Динамічна вправа для м\'язів живота та косих м\'язів. 15-20 повторень.', 4, 6.50, 4.50, 2, '["abs","obliques"]', '[]'),
(13, 'Мостик (підйом стегон)', 'Вправа для сідниць та задньої поверхні стегна. 12-15 повторень.', 4, 5.50, 3.50, 1, '["glutes","hamstrings"]', '[]'),
(14, 'Альпініст (Mountain Climbers)', 'Динамічна кардіо вправа. Задіює кор та ноги.', 5, 10.50, 8.00, 3, '["core","legs","cardio"]', '[2,4]'),
(15, 'Ходьба на місці', 'Легка кардіо вправа для розминки та заминки. Низька інтенсивність.', 10, 4.00, 3.50, 1, '["legs","cardio"]', '[]');

-- Тестовий план тренувань
INSERT INTO `workout_plans` (`id`, `user_id`, `start_date`, `status`) VALUES
(1, 1, '2026-06-15', 'active');

-- Тестове тренування
INSERT INTO `workout_sessions` (`id`, `plan_id`, `session_date`, `duration`, `calories_burned`, `completed_at`) VALUES
(1, 1, '2026-06-15 09:00:00', 30, 245.50, '2026-06-15 09:30:00');

-- Вправи в тренуванні
INSERT INTO `session_exercises` (`session_id`, `exercise_id`, `sets`, `reps`, `completed`) VALUES
(1, 2, 3, 12, 1),
(1, 3, 3, 45, 1),
(1, 6, 3, 15, 1),
(1, 15, 1, 5, 1);

-- Тестові дані пульсу
INSERT INTO `heart_rate_logs` (`user_id`, `timestamp`, `bpm`, `source`) VALUES
(1, '2026-06-15 09:05:00', 125, 'manual'),
(1, '2026-06-15 09:15:00', 138, 'manual'),
(1, '2026-06-15 09:25:00', 142, 'manual'),
(1, '2026-06-17 10:30:00', 72, 'manual');

-- Історія ваги
INSERT INTO `weight_logs` (`user_id`, `weight`, `logged_at`) VALUES
(1, 85.50, '2026-06-01 08:00:00'),
(1, 84.80, '2026-06-08 08:00:00'),
(1, 84.20, '2026-06-15 08:00:00');

COMMIT;
