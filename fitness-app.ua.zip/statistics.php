<?php
require_once __DIR__ . '/includes/config.php';
session_start();
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireAuth();

$userId = getCurrentUserId();
$db = new Database();

// Отримати статистику за різні періоди
$stats7 = getUserStats($userId, 7);
$stats30 = getUserStats($userId, 30);
$stats90 = getUserStats($userId, 90);

// Історія тренувань (останні 10)
$workoutHistory = $db->query(
    "SELECT ws.*, ws.completed_at as date,
            (SELECT COUNT(*) FROM session_exercises se WHERE se.session_id = ws.id) as exercises_count,
            (SELECT COUNT(*) FROM session_exercises se WHERE se.session_id = ws.id AND se.completed = 1) as completed_exercises
     FROM workout_sessions ws
     JOIN workout_plans wp ON wp.id = ws.plan_id
     WHERE wp.user_id = ? AND ws.completed_at IS NOT NULL
     ORDER BY ws.completed_at DESC
     LIMIT 10",
    [$userId]
);

// Історія ваги
$weightHistory = $db->query(
    "SELECT weight, logged_at FROM weight_logs WHERE user_id = ? ORDER BY logged_at ASC",
    [$userId]
);

// Профіль для розрахунків
$profile = $db->fetchOne(
    "SELECT * FROM user_profiles WHERE user_id = ?",
    [$userId]
);

$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Статистика - Фітнес Платформа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>

    <div class="container my-5">
        <h2 class="mb-4">Статистика та прогрес</h2>

        <!-- Вибір періоду -->
        <ul class="nav nav-pills mb-4" id="periodTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="week-tab" data-bs-toggle="pill" data-bs-target="#week" type="button">7 днів</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="month-tab" data-bs-toggle="pill" data-bs-target="#month" type="button">30 днів</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="quarter-tab" data-bs-toggle="pill" data-bs-target="#quarter" type="button">90 днів</button>
            </li>
        </ul>

        <div class="tab-content" id="periodContent">
            <!-- 7 днів -->
            <div class="tab-pane fade show active" id="week" role="tabpanel">
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body text-center">
                                <h6 class="opacity-75">Тренувань</h6>
                                <h2><?= $stats7['workouts_count'] ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body text-center">
                                <h6 class="opacity-75">Спалено калорій</h6>
                                <h2><?= number_format($stats7['total_calories'], 0) ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body text-center">
                                <h6 class="opacity-75">Загальний час (хв)</h6>
                                <h2><?= $stats7['total_duration'] ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 30 днів -->
            <div class="tab-pane fade" id="month" role="tabpanel">
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body text-center">
                                <h6 class="opacity-75">Тренувань</h6>
                                <h2><?= $stats30['workouts_count'] ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body text-center">
                                <h6 class="opacity-75">Спалено калорій</h6>
                                <h2><?= number_format($stats30['total_calories'], 0) ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body text-center">
                                <h6 class="opacity-75">Загальний час (хв)</h6>
                                <h2><?= $stats30['total_duration'] ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 90 днів -->
            <div class="tab-pane fade" id="quarter" role="tabpanel">
                <div class="row g-4 mb-4">
                    <div class="col-md-4">
                        <div class="card stat-card bg-primary text-white">
                            <div class="card-body text-center">
                                <h6 class="opacity-75">Тренувань</h6>
                                <h2><?= $stats90['workouts_count'] ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stat-card bg-success text-white">
                            <div class="card-body text-center">
                                <h6 class="opacity-75">Спалено калорій</h6>
                                <h2><?= number_format($stats90['total_calories'], 0) ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card stat-card bg-info text-white">
                            <div class="card-body text-center">
                                <h6 class="opacity-75">Загальний час (хв)</h6>
                                <h2><?= $stats90['total_duration'] ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Графік ваги -->
        <?php if (!empty($weightHistory)): ?>
        <div class="card shadow mb-4">
            <div class="card-body">
                <h5 class="card-title mb-4">Динаміка ваги</h5>
                <canvas id="weightChart" height="80"></canvas>
            </div>
        </div>

        <script>
            const weightData = <?= json_encode($weightHistory) ?>;
            const ctx = document.getElementById('weightChart').getContext('2d');
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: weightData.map(d => new Date(d.logged_at).toLocaleDateString('uk-UA')),
                    datasets: [{
                        label: 'Вага (кг)',
                        data: weightData.map(d => d.weight),
                        borderColor: 'rgb(75, 192, 192)',
                        backgroundColor: 'rgba(75, 192, 192, 0.1)',
                        tension: 0.3,
                        fill: true,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }<?php if ($profile && $profile['goal_weight']): ?>,
                    {
                        label: 'Цільова вага',
                        data: Array(weightData.length).fill(<?= $profile['goal_weight'] ?>),
                        borderColor: 'rgb(255, 99, 132)',
                        borderDash: [5, 5],
                        pointRadius: 0,
                        fill: false
                    }<?php endif; ?>]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        },
                        tooltip: {
                            mode: 'index',
                            intersect: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: false,
                            title: {
                                display: true,
                                text: 'Вага (кг)'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Дата'
                            }
                        }
                    }
                }
            });
        </script>
        <?php endif; ?>

        <!-- Історія тренувань -->
        <div class="card shadow">
            <div class="card-body">
                <h5 class="card-title mb-4">Історія тренувань</h5>

                <?php if (!empty($workoutHistory)): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Дата</th>
                                    <th>Тривалість</th>
                                    <th>Вправи</th>
                                    <th>Калорії</th>
                                    <th>Середній пульс</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($workoutHistory as $workout): ?>
                                    <tr>
                                        <td><?= formatDate($workout['date'], 'd.m.Y H:i') ?></td>
                                        <td><?= $workout['duration'] ?> хв</td>
                                        <td>
                                            <span class="badge bg-primary">
                                                <?= $workout['completed_exercises'] ?>/<?= $workout['exercises_count'] ?>
                                            </span>
                                        </td>
                                        <td><?= number_format($workout['calories_burned'], 0) ?> ккал</td>
                                        <td>
                                            <?= $workout['heart_rate_avg'] ? $workout['heart_rate_avg'] . ' уд/хв' : '-' ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-muted text-center py-4">Ще немає завершених тренувань</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
</body>
</html>
