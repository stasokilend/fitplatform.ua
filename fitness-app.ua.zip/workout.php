<?php
require_once __DIR__ . '/includes/config.php';
session_start();
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

requireAuth();

$userId = getCurrentUserId();
$db = new Database();

$error = '';
$success = '';

// Обробка дій
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'generate') {
        // Генерувати нове тренування
        $result = generateWorkout($userId);

        if ($result) {
            $success = 'Тренування успішно створено!';
        } else {
            $error = 'Не вдалося створити тренування. Можливо, немає доступних вправ для вашого профілю.';
        }
    } elseif ($action === 'toggle_exercise') {
        // Відмітити вправу як виконану/невиконану
        $exerciseId = intval($_POST['exercise_id'] ?? 0);
        $completed = intval($_POST['completed'] ?? 0);

        $db->execute(
            "UPDATE session_exercises SET completed = ? WHERE id = ?",
            [$completed, $exerciseId]
        );
    } elseif ($action === 'complete') {
        // Завершити тренування
        $sessionId = intval($_POST['session_id'] ?? 0);

        if (completeWorkout($sessionId, $userId)) {
            // Оновити статус плану
            $db->execute(
                "UPDATE workout_plans wp
                 JOIN workout_sessions ws ON ws.plan_id = wp.id
                 SET wp.status = 'completed', wp.end_date = CURDATE()
                 WHERE ws.id = ?",
                [$sessionId]
            );

            $success = 'Тренування завершено! Вітаємо!';
            header('Location: /statistics.php');
            exit;
        } else {
            $error = 'Помилка завершення тренування';
        }
    }
}

// Отримати активне тренування
$workout = getActiveWorkout($userId);

$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Моє тренування - Фітнес Платформа</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <?php include __DIR__ . '/includes/header.php'; ?>

    <div class="container my-5">
        <h2 class="mb-4">Моє тренування</h2>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?= e($success) ?></div>
        <?php endif; ?>

        <?php if ($workout): ?>
            <div class="card shadow">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h4 class="mb-1">Тренування на <?= formatDate($workout['session']['session_date'], 'd.m.Y') ?></h4>
                            <p class="text-muted mb-0">Кількість вправ: <?= count($workout['exercises']) ?></p>
                        </div>
                        <form method="POST" action="" onsubmit="return confirm('Завершити тренування?')">
                            <input type="hidden" name="action" value="complete">
                            <input type="hidden" name="session_id" value="<?= $workout['session']['id'] ?>">
                            <button type="submit" class="btn btn-success btn-lg">Завершити тренування</button>
                        </form>
                    </div>

                    <div class="exercises-list">
                        <?php foreach ($workout['exercises'] as $index => $exercise): ?>
                            <div class="exercise-item card mb-3 <?= $exercise['completed'] ? 'border-success' : '' ?>">
                                <div class="card-body">
                                    <div class="row align-items-center">
                                        <div class="col-auto">
                                            <div class="exercise-number"><?= $index + 1 ?></div>
                                        </div>
                                        <div class="col">
                                            <h5 class="mb-1 <?= $exercise['completed'] ? 'text-decoration-line-through' : '' ?>">
                                                <?= e($exercise['name']) ?>
                                            </h5>
                                            <p class="text-muted mb-2"><?= e($exercise['description']) ?></p>
                                            <div class="exercise-details">
                                                <span class="badge bg-primary me-2">Підходів: <?= $exercise['sets'] ?></span>
                                                <span class="badge bg-info me-2">Повторень: <?= $exercise['reps'] ?></span>
                                                <span class="badge bg-secondary me-2">~<?= $exercise['duration'] ?> хв</span>
                                                <span class="badge bg-warning">~<?= round($exercise['calories_per_min'] * $exercise['duration']) ?> ккал</span>
                                            </div>
                                            <?php
                                            $muscleGroups = json_decode($exercise['muscle_groups'], true);
                                            if ($muscleGroups):
                                            ?>
                                                <div class="mt-2">
                                                    <small class="text-muted">
                                                        М'язові групи: <?= implode(', ', $muscleGroups) ?>
                                                    </small>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-auto">
                                            <div class="form-check form-switch">
                                                <input class="form-check-input exercise-toggle" type="checkbox"
                                                       data-exercise-id="<?= $exercise['id'] ?>"
                                                       <?= $exercise['completed'] ? 'checked' : '' ?>>
                                                <label class="form-check-label">Виконано</label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php
                    // Розрахунок прогресу
                    $completedCount = count(array_filter($workout['exercises'], fn($e) => $e['completed']));
                    $totalCount = count($workout['exercises']);
                    $progressPercent = $totalCount > 0 ? round(($completedCount / $totalCount) * 100) : 0;
                    ?>

                    <div class="mt-4">
                        <h6>Прогрес виконання</h6>
                        <div class="progress" style="height: 25px;">
                            <div class="progress-bar bg-success" role="progressbar"
                                 style="width: <?= $progressPercent ?>%"
                                 aria-valuenow="<?= $progressPercent ?>" aria-valuemin="0" aria-valuemax="100">
                                <?= $completedCount ?> / <?= $totalCount ?> (<?= $progressPercent ?>%)
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        <?php else: ?>
            <div class="card shadow text-center py-5">
                <div class="card-body">
                    <h4 class="text-muted mb-4">У вас немає активного тренування</h4>
                    <p class="mb-4">Створіть персоналізоване тренування на основі вашого профілю</p>
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="generate">
                        <button type="submit" class="btn btn-primary btn-lg">Створити тренування</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/assets/js/script.js"></script>
    <script>
        // AJAX для відмітки вправ
        document.querySelectorAll('.exercise-toggle').forEach(toggle => {
            toggle.addEventListener('change', function() {
                const exerciseId = this.dataset.exerciseId;
                const completed = this.checked ? 1 : 0;

                fetch('/workout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=toggle_exercise&exercise_id=${exerciseId}&completed=${completed}`
                })
                .then(() => {
                    // Оновити сторінку для перерахунку прогресу
                    location.reload();
                })
                .catch(error => {
                    console.error('Error:', error);
                    this.checked = !this.checked;
                });
            });
        });
    </script>
</body>
</html>
