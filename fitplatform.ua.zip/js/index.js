// js/index.js - Логіка для головної сторінки

document.addEventListener('DOMContentLoaded', function() {
    // Перевіряємо, чи авторизований користувач
    fetch(API_BASE + 'profile.php')
        .then(res => res.json())
        .then(data => {
            if (data.success && data.profile) {
                // Користувач авторизований
                const profile = data.profile;
                
                // Ховаємо кнопки входу/реєстрації
                document.getElementById('navLogin').style.display = 'none';
                document.getElementById('navRegister').style.display = 'none';
                
                // Показуємо кнопки кабінету та виходу
                document.getElementById('navDashboard').style.display = 'block';
                document.getElementById('navLogout').style.display = 'block';
                
                // Показуємо кнопку адмін-панелі, якщо є права
                if (profile.role && ['admin', 'trainer'].includes(profile.role)) {
                    document.getElementById('navAdmin').style.display = 'block';
                }
                
                // Змінюємо hero-секцію
                document.getElementById('heroButtons').style.display = 'none';
                document.getElementById('heroDashboard').style.display = 'block';
                
                // Обробник виходу
                document.getElementById('logoutBtnIndex').addEventListener('click', function(e) {
                    e.preventDefault();
                    logout();
                });
                
                // Показуємо тост-привітання
                showToast('👋 Вітаємо, ' + (profile.full_name || 'користувач') + '!', 'success', 3000);
                
            } else {
                // Користувач не авторизований – показуємо кнопки входу/реєстрації
                document.getElementById('navLogin').style.display = 'block';
                document.getElementById('navRegister').style.display = 'block';
                document.getElementById('navDashboard').style.display = 'none';
                document.getElementById('navLogout').style.display = 'none';
                document.getElementById('navAdmin').style.display = 'none';
                document.getElementById('heroButtons').style.display = 'block';
                document.getElementById('heroDashboard').style.display = 'none';
            }
        })
        .catch(() => {
            // Якщо помилка – показуємо стандартні кнопки
            document.getElementById('navLogin').style.display = 'block';
            document.getElementById('navRegister').style.display = 'block';
            document.getElementById('navDashboard').style.display = 'none';
            document.getElementById('navLogout').style.display = 'none';
            document.getElementById('navAdmin').style.display = 'none';
            document.getElementById('heroButtons').style.display = 'block';
            document.getElementById('heroDashboard').style.display = 'none';
        });
});